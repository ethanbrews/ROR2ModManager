﻿using ROR2ModManager.API;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Networking.BackgroundTransfer;
using System.Threading.Tasks;
using System.Threading;
using System.IO.Compression;
using Windows.Storage;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace ROR2ModManager.Pages.Install
{

    public class DoInstallParameters
    {
        public List<Package> Packages;
        public string ProfileName;
        private List<DownloadOperation> downloads = new List<DownloadOperation>();
    }

    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class DoInstall : Page
    {

        BackgroundDownloader downloader;
        DoInstallParameters parameters;
        private static IList<char> invalidFileNameChars = Path.GetInvalidFileNameChars();
        List<DownloadOperation> downloads = new List<DownloadOperation>();
        private CancellationTokenSource cts;
        HashSet<string> completed = new HashSet<string>();
        private int _downloads_done;
        private int _installs_done;
        private List<string> _failed_packs = new List<string>();
        private List<string> _retried_packs = new List<string>();

        public DoInstall()
        {
            cts = new CancellationTokenSource();
            this.InitializeComponent();
        }

        public void Dispose()
        {
            if (cts != null)
            {
                cts.Dispose();
                cts = null;
            }

            GC.SuppressFinalize(this);
        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            ResetVars();
            parameters = ((DoInstallParameters)e.Parameter);
            downloader = new BackgroundDownloader();

            var tempdir = Windows.Storage.ApplicationData.Current.TemporaryFolder;

            //For each file, download zip to a file in temp dir named using pkg.full_name, each invalid char is shifted into the ASCII range [A-z];
            foreach (var pkg in parameters.Packages)
                if(!System.IO.File.Exists(Path.Combine(ApplicationData.Current.LocalFolder.Path, pkg.full_name)))
                    _ = HandleDownloadAsync(downloader.CreateDownload(new Uri(pkg.versions.Where((x) => x.version_number == pkg._selected_version).First().download_url), await tempdir.CreateFileAsync(new string(pkg.full_name.Select(ch => invalidFileNameChars.Contains(ch) ? Convert.ToChar(invalidFileNameChars.IndexOf(ch) + 65) : ch).ToArray()), Windows.Storage.CreationCollisionOption.ReplaceExisting)), true);


        }

        private void CancelAll_Click(object sender, RoutedEventArgs e)
        {

            cts.Cancel();
            cts.Dispose();
            // Re-create the CancellationTokenSource and activeDownloads for future downloads.
            ResetVars();
        }

        private void ResetVars()
        {
            cts = new CancellationTokenSource();
            downloads = new List<DownloadOperation>();
            completed.Clear();
            ProgressBar.Value = 0;
            _downloads_done = 0;
            _installs_done = 0;
            _failed_packs.Clear();
            _retried_packs.Clear();
        }

        private void AddToProgressBar()
        {
            ProgressBar.Value += 100 / (parameters.Packages.Count() * 2);
        }

        private void AddToDownloadsCount() {
            DownloadAmount.Text = $"Downloaded {++_downloads_done}/{parameters.Packages.Count()}";
        }

        private void AddToFailedPacks(string p)
        {
            _failed_packs.Add(p);
            FailAmount.Text = $"{_failed_packs.Count()} packs failed to install";
        }

        private void AddToInstallsCount()
        {
            DownloadAmount.Text = $"Installed {++_installs_done}/{parameters.Packages.Count()}";
        }

        private async void FinishInstallation()
        {
            await ProfileManager.AddNewProfile(parameters.ProfileName, parameters.Packages.ToArray());

            if (_failed_packs.Count() > 0)
            {
                MainPage.Instance.contentFrame.Navigate(typeof(Pages.Play), new Pages.PlayParameters {
                    contentDialogToShow = new FailuresDetailsContentDialog
                    {
                        fails = _failed_packs.ToArray()
                    }
                });
            } else
            {
                MainPage.Instance.contentFrame.Navigate(typeof(Pages.Play));
            }
            
        }

        private void addToOutputList(string txt)
        {
            System.Diagnostics.Debug.WriteLine(txt);
            /*
            ListViewItem item = new ListViewItem();
            TextBlock mytext = new TextBlock();
            mytext.Text = txt;
            item.Content = mytext;
            OutputList.Items.Add(item);
            */
            
        }

        private async Task HandleDownloadAsync(DownloadOperation download, bool start)
        {
            try
            {
                // Store the download so we can pause/resume.
                downloads.Add(download);
                addToOutputList($"Start download for {download.ResultFile.Name} ({download.RequestedUri.ToString()})");

                Progress<DownloadOperation> progressCallback = new Progress<DownloadOperation>(DownloadProgress);
                if (start)
                {
                    // Start the download and attach a progress handler.
                    await download.StartAsync().AsTask(cts.Token, progressCallback);
                }
                else
                {
                    // The download was already running when the application started, re-attach the progress handler.
                    await download.AttachAsync().AsTask(cts.Token, progressCallback);
                }

                ResponseInformation response = download.GetResponseInformation();

            }
            catch (TaskCanceledException)
            {
                
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                downloads.Remove(download);
            }
        }

        private async void DownloadProgress(DownloadOperation obj)
        {
            addToOutputList($"prog {obj.Progress.Status.ToString()} {obj.ResultFile.Name}");
            if (obj.Progress.Status == BackgroundTransferStatus.Completed || obj.Progress.BytesReceived == obj.Progress.TotalBytesToReceive)
            {
                if (completed.Contains(obj.ResultFile.Name))
                    return;
                completed.Add(obj.ResultFile.Name);
                AddToDownloadsCount();
                addToOutputList($"unzip {obj.ResultFile.Name} (at {obj.ResultFile.Path})");
                var targetdir = await Windows.Storage.ApplicationData.Current.LocalFolder.CreateFolderAsync(obj.ResultFile.Name, Windows.Storage.CreationCollisionOption.ReplaceExisting);
                Stream a = await obj.ResultFile.OpenStreamForReadAsync();
                

                //unzip
                try
                {
                    ZipArchive archive = new ZipArchive(a);
                    archive.ExtractToDirectory(targetdir.Path);
                } catch (System.IO.InvalidDataException)
                {
                    if (!_retried_packs.Contains(obj.ResultFile.Name))
                    {
                        System.Diagnostics.Debug.WriteLine("Retrying " + obj.ResultFile.Name);
                        _retried_packs.Add(obj.ResultFile.Name);
                        downloader.CreateDownload(obj.RequestedUri, obj.ResultFile);
                    } else
                    {
                        System.Diagnostics.Debug.WriteLine("A file failed to download 2 times in a row: " + obj.ResultFile.Name);
                        addToOutputList($"InvalidDataException {obj.ResultFile.Name}");
                        AddToFailedPacks(obj.ResultFile.Name);
                    }
                    
                    
                } finally
                {
                    AddToInstallsCount();
                    if (_installs_done == parameters.Packages.Count())
                    {
                        //Installs all complete.
                        ProgressBar.IsIndeterminate = true;
                        FinishInstallation();
                    }
                }
                
            }
        }
    }
}
